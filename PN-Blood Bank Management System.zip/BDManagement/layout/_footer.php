<footer class="foter">
            <b>&COPY; <a href="http://projectnotes.org">ProjectNotes</a></b>
            <br>
</footer>



</body>
</html>
